<script setup>

</script>


<template>
<div>
<header>
        header
</header>
<slot/>
<footer>
        footer
</footer>
</div>
</template>
<style>
.box{
        background-color: aqua;
}
</style>