
<script setup>

</script>
<template >
    <div>
        <button class="flex items-center justify-center

        px-3 py-2 bg-orange-400	 rounded-lg cursor-pointer shadow-md text-white" >

  <slot/> 
        </button>
    </div>
</template>